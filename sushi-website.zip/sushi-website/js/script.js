// import images as relative image path won't work with vite/vercel.
// import check from '../assets/check.svg';
// import star from '../assets/star/.svg';
// import sushi12 from '../assets/sushi-12/.png';
// import sushi11 from '../assets/sushi-11/.png';
// import sushi10 from '../assets/sushi-10/.png';

const about = document.querySelectorAll('[data-about]');
const popular = document.querySelectorAll('[data-popular]');
const trending = document.querySelectorAll('[data-trending]');

const trendingSushis = [
  'Make Sushi',
  'Nigri Sushi',
  'Oshizushi',
  'Temaki Sushi',
  'Oramaki Sushi',
  'Inari Sushi',
];
window.addEventListener('DOMContentLoaded', () => {
  if (window.scrollY > 280) {
    about[0].classList.add('fade-right');
  }
  if (window.scrollY > 300) {
    about[2].classList.add('fade-left');
  }
  if (window.scrollY > 650) {
    about[1].classList.add('fade-right');
  }
  if (window.scrollY > 1000) {
    popular[0].classList.add('flip-up');
  }
  if (window.scrollY > 1080) {
    popular[1].classList.add('fade-up');
  }
  if (window.scrollY > 1250) {
    popular[2].classList.add('fade-up');
  }
  if (window.scrollY > 2060) {
    trending[0].classList.add('fade-right');
    trending[1].classList.add('fade-left');
  }
  if (window.scrollY > 2440) {
    trending[2].classList.add('zoom-in');
  }
  if (window.scrollY > 2690) {
    trending[3].classList.add('fade-left');
  }
  if (window.scrollY > 2690) {
    trending[4].classList.add('fade-right');
  }
});
// window
window.addEventListener('scroll', () => {
  if (window.scrollY > 280) {
    about[0].classList.add('fade-right');
  }
  if (window.scrollY > 300) {
    about[2].classList.add('fade-left');
  }
  if (window.scrollY > 650) {
    about[1].classList.add('fade-right');
  }
  if (window.scrollY > 1000) {
    popular[0].classList.add('flip-up');
  }
  if (window.scrollY > 1080) {
    popular[1].classList.add('fade-up');
  }
  if (window.scrollY > 1250) {
    popular[2].classList.add('fade-up');
  }
  if (window.scrollY > 2060) {
    trending[0].classList.add('fade-right');
    trending[1].classList.add('fade-left');
  }
  if (window.scrollY > 2440) {
    trending[2].classList.add('zoom-in');
  }
  if (window.scrollY > 2690) {
    trending[3].classList.add('fade-left');
  }
  if (window.scrollY > 2690) {
    trending[4].classList.add('fade-right');
  }

  // console.log(window.scrollY);
});
